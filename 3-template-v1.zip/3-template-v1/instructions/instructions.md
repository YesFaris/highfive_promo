# Exercice dirigé: Template

## Page index.html
* Créer un nouveau fichier HTML "index.html"
* Faire la structure principale du document
* Récupérer le texte de la page et mettre chaque partie entre les bonnes balises
* Créer un nouveau fichier "common-v1.css" et la remplir en suivant les instructions du formateur
* Créer un nouveau fichier "theme.css" et le garder vide
* Relier les feuilles de style au document HTML avec les balises LINK

## Feuille de style common-v1.css

Il s'agit de la feuille de style commune de tous les exercices dirigés du module 1.
Il y aura deux autres versions de cette feuille de style:
* la version 2 réalisée dans le module 2
* la version 3 réalisée dans le module 3 pour tous les autres modules (3, 4, 5 et 6)

Cette feuille de style peut être réutilisée en cours de DEV pour vous faire gagner du temps

## Feuille de style theme.css

Cette feuille de style (ici vide) servira dans les autres exercices du module pour y placer le code CSS propre à chaque exercice.
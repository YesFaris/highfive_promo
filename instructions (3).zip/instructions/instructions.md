# Exercice dirigé: Emmet

## Code

Placer le code dans des éléments <pre>

Utiliser les propriétés suivantes:
* Police: Monaco, monospace
* Taille: 14px
* Couleur: #000
* Couleur du fond: #fff
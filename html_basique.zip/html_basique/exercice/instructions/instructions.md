# Exercice dirigé: Balises

## Page index.html
* Créer un nouveau fichier HTML "index.html"
* Faire la structure principale du document
* Récupérer le texte de la page et mettre chaque partie entre les bonnes balises

## Page index-style.html
* Dupliquer la page "index.html"
* Ajouter le style directement dans l'entête du document
* Mettre tous les H1 en rouge
* Ajouter une classe .colored aux éléments DIV et SPAN et leur ajouter la couleur verte

## Page index-link.html
* Dupliquer la page "index-style.html"
* Créer un nouveau fichier "style.css"
* Transférer le code de l'élément STYLE vers ce fichier
* Remplacer la l'élément STYLE par une balise LINK qui fait référence à la feuille de style "style.css"

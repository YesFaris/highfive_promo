# Exercice dirigé: Colonnes avec display inline-block

## Blocks
* Faire un parent section avec la classe .parent
* Faire deux articles avec la classe .card
* Y ajouter du lorem ipsum


# Liste des exercices associés à ce module pour révision et entraînement.

- https://apprendre-html.3wa.fr/css/comprendre-css/bouton-css/introduction-creer-bouton-html-partir-lien (Et les 5 suivant sur le même thème dans "Apprendre HTML")
- https://apprendre-html.3wa.fr/css/css-positionnement/css-positionner-html/position-flottant-droite-css
- https://apprendre-html.3wa.fr/css/css-positionnement/css-positionner-html/position-flottant-gauche-css
- https://apprendre-html.3wa.fr/css/css-positionnement/css-positionner-html/utiliser-propriete-clear-liberer-div


# Liste des exercices sur la syntaxe des déclarations CSS et sur les sélecteurs CSS.


## Exercices de révision et d'entraînement utiles pour tous les modules à partir du module M03.



La syntaxe CSS de base.


- https://apprendre-html.3wa.fr/css/comprendre-css/css-style-html/utiliser-balise-link-lier-feuille-style-css-page-html
- https://apprendre-html.3wa.fr/css/comprendre-css/css-style-html/lier-css-html-attributs-type-rel-href
- https://apprendre-html.3wa.fr/css/comprendre-css/css-style-html/syntaxe-css-definir-style-elements-html
- https://apprendre-html.3wa.fr/css/comprendre-css/css-style-html/utiliser-points-virgules-accolades-document-css

Les sélecteurs CSS de base.


- https://apprendre-html.3wa.fr/css/css-classes-ids/selecteurs-css/tous-elements-html-sont-selecteurs-css
- https://apprendre-html.3wa.fr/css/css-classes-ids/selecteurs-css/selecteurs-multiples-css
- https://apprendre-html.3wa.fr/css/css-classes-ids/selecteurs-css/selecteur-universel-css
- https://apprendre-html.3wa.fr/css/css-classes-ids/selecteurs-css/notion-specificite-selecteurs-css
- https://apprendre-html.3wa.fr/css/css-classes-ids/selecteurs-css/representation-structure-page-html
- https://apprendre-html.3wa.fr/css/css-classes-ids/selecteurs-css/utiliser-class-id-styles-specifiques-page-html
- https://apprendre-html.3wa.fr/css/css-classes-ids/selecteurs-css/fonctionnement-selecteur-class-css
- https://apprendre-html.3wa.fr/css/css-classes-ids/selecteurs-css/fonctionnement-selecteur-id-css
